<?php
/**
 * Theme functions and definitions
 */

if ( ! function_exists( 'biswas_company_wp_setup' ) ) :
function biswas_company_wp_setup() {
    // Make theme available for translation
    load_theme_textdomain( 'biswas-company-wp', get_template_directory() . '/languages' );

    // Add default posts and comments RSS feed links to head
    add_theme_support( 'automatic-feed-links' );

    // Let WordPress manage the document title
    add_theme_support( 'title-tag' );

    // Enable support for Post Thumbnails on posts and pages
    add_theme_support( 'post-thumbnails' );

    // Enable support for custom logo
    add_theme_support( 'custom-logo', array(
        'height'      => 100,
        'width'       => 400,
        'flex-height' => true,
        'flex-width'  => true,
    ) );

    // Switch default core markup for search form, comment form, and comments to output valid HTML5
    add_theme_support( 'html5', array(
        'search-form',
        'comment-form',
        'comment-list',
        'gallery',
        'caption',
    ) );

    // Register navigation menus
    register_nav_menus( array(
        'primary' => esc_html__( 'Primary Menu', 'biswas-company-wp' ),
    ) );

    // Add theme support for Elementor
    add_theme_support( 'elementor' );

    // Add theme support for Elementor's theme builder
    add_theme_support( 'elementor-theme-builder' );

    // Add editor styles
    add_theme_support( 'editor-styles' );
    add_editor_style( 'editor-style.css' );
}
endif;
add_action( 'after_setup_theme', 'biswas_company_wp_setup' );

/**
 * Enqueue scripts and styles
 */
function biswas_company_wp_scripts() {
    // Enqueue main stylesheet
    wp_enqueue_style( 'biswas-company-wp-style', get_stylesheet_uri() );

    // Enqueue Elementor's frontend styles if Elementor is active
    if ( did_action( 'elementor/loaded' ) ) {
        wp_enqueue_style( 'elementor-frontend' );
    }
}
add_action( 'wp_enqueue_scripts', 'biswas_company_wp_scripts' );

/**
 * Register widget area
 */
function biswas_company_wp_widgets_init() {
    register_sidebar( array(
        'name'          => esc_html__( 'Sidebar', 'biswas-company-wp' ),
        'id'            => 'sidebar-1',
        'description'   => esc_html__( 'Add widgets here to appear in your sidebar.', 'biswas-company-wp' ),
        'before_widget' => '<section id="%1$s" class="widget %2$s">',
        'after_widget'  => '</section>',
        'before_title'  => '<h2 class="widget-title">',
        'after_title'   => '</h2>',
    ) );
}
add_action( 'widgets_init', 'biswas_company_wp_widgets_init' );
