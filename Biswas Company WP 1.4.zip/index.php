<?php get_header(); ?>

<main id="primary" class="site-main">
    <div class="content-area">
        <header class="page-header">
            <h1 class="page-title"><?php echo esc_html__( 'Latest Posts', 'biswas-company-wp' ); ?></h1>
        </header>

        <div class="posts-list">
            <?php if ( have_posts() ) : ?>
                <?php while ( have_posts() ) : the_post(); ?>
                    <article id="post-<?php the_ID(); ?>" <?php post_class( 'post-item' ); ?>>
                        <?php if ( has_post_thumbnail() ) : ?>
                            <div class="post-thumbnail">
                                <a href="<?php the_permalink(); ?>">
                                    <?php the_post_thumbnail( 'large' ); ?>
                                </a>
                            </div>
                        <?php endif; ?>

                        <div class="post-content">
                            <header class="entry-header">
                                <h2 class="entry-title">
                                    <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                                </h2>
                            </header><!-- .entry-header -->

                            <div class="entry-content">
                                <?php the_excerpt(); ?>
                            </div><!-- .entry-content -->

                            <footer class="entry-footer">
                                <a href="<?php the_permalink(); ?>" class="read-more">
                                    <?php echo esc_html__( 'Read more', 'biswas-company-wp' ); ?>
                                </a>
                            </footer><!-- .entry-footer -->
                        </div><!-- .post-content -->
                    </article><!-- #post-${ID} -->
                <?php endwhile; ?>

                <div class="pagination">
                    <?php the_posts_pagination( array(
                        'prev_text' => esc_html__( 'Previous', 'biswas-company-wp' ),
                        'next_text' => esc_html__( 'Next', 'biswas-company-wp' ),
                    ) ); ?>
                </div>

            <?php else : ?>
                <?php get_template_part( 'template-parts/content', 'none' ); ?>
            <?php endif; ?>
        </div><!-- .posts-list -->
    </div><!-- .content-area -->
</main><!-- #primary -->

<?php get_footer(); ?>
