    <footer id="colophon" class="site-footer">
        <div class="container">
            <p>&copy; <?php echo date('Y'); ?> - Biswas Company WP</p>
        </div>
        <?php wp_footer(); ?>
    </footer>
</body>
</html>
