<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
    <header id="masthead" class="site-header">
        <div class="container">
            <div class="site-branding">
                <?php if ( has_custom_logo() ) {
                    the_custom_logo();
                } else {
                    echo '<h1>' . get_bloginfo( 'name' ) . '</h1>';
                } ?>
            </div>
            <nav id="site-navigation" class="main-navigation">
                <?php
                wp_nav_menu( array(
                    'theme_location' => 'default_menu',
                    'menu_id'        => 'primary-menu',
                    'menu_class'     => 'default-menu-class', // Add your custom classes here
                ) );
                ?>
            </nav>
        </div>
    </header>
    <?php wp_footer(); ?>
</body>
</html>
